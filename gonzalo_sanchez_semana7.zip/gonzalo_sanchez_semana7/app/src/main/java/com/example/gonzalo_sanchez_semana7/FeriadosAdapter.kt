package com.example.gonzalo_sanchez_semana7

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FeriadosAdapter(private var feriados: List<Feriado>) : RecyclerView.Adapter<FeriadosAdapter.FeriadoViewHolder>() {

    class FeriadoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nombre: TextView = view.findViewById(R.id.nombre)
        val fecha: TextView = view.findViewById(R.id.fecha)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FeriadoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_feriado, parent, false)
        return FeriadoViewHolder(view)
    }

    override fun onBindViewHolder(holder: FeriadoViewHolder, position: Int) {
        val feriado = feriados[position]
        holder.nombre.text = feriado.nombre
        holder.fecha.text = feriado.fecha
    }

    override fun getItemCount(): Int = feriados.size

    fun updateData(newFeriados: List<Feriado>) {
        feriados = newFeriados
        notifyDataSetChanged()
    }
}
