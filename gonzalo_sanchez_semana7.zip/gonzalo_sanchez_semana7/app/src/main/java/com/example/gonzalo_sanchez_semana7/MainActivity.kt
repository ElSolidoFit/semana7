package com.example.gonzalo_sanchez_semana7

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

data class Feriado(val nombre: String, val fecha: String)

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var feriadosAdapter: FeriadosAdapter
    private lateinit var welcomeText: TextView
    private lateinit var logoutButton: Button
    private lateinit var yearSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        welcomeText = findViewById(R.id.welcomeText)
        logoutButton = findViewById(R.id.logoutButton)
        recyclerView = findViewById(R.id.recyclerView)
        yearSpinner = findViewById(R.id.yearSpinner)

        val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val username = sharedPreferences.getString("username", "")
        welcomeText.text = "Bienvenido: $username"

        recyclerView.layoutManager = LinearLayoutManager(this)
        feriadosAdapter = FeriadosAdapter(listOf())
        recyclerView.adapter = feriadosAdapter

        // Setup the Spinner
        val years = resources.getStringArray(R.array.years_array)
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, years)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        yearSpinner.adapter = spinnerAdapter

        yearSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val selectedYear = years[position]
                FetchFeriadosTask().execute("https://apis.digital.gob.cl/fl/feriados/2024")
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Handle the case when no item is selected if needed
            }
        }

        logoutButton.setOnClickListener {
            sharedPreferences.edit().apply {
                clear()
                apply()
            }
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private inner class FetchFeriadosTask : AsyncTask<String, Void, List<Feriado>?>() {
        override fun doInBackground(vararg urls: String): List<Feriado>? {
            val client = OkHttpClient()
            val request = Request.Builder().url(urls[0]).build()
            return try {
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val json = response.body?.string()
                    val listType = object : TypeToken<List<Feriado>>() {}.type
                    Gson().fromJson<List<Feriado>>(json, listType)
                } else {
                    Log.e("FetchFeriadosTask", "Request failed: ${response.message}")
                    null
                }
            } catch (e: IOException) {
                Log.e("FetchFeriadosTask", "Exception during API call", e)
                null
            }
        }

        override fun onPostExecute(result: List<Feriado>?) {
            if (result != null) {
                feriadosAdapter.updateData(result)
            } else {
                Toast.makeText(this@MainActivity, "Error fetching data", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
